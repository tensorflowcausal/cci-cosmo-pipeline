#!/usr/bin/env python3
# Post-procesado básico de la salida de CLASS para CET Ω
# - Lee espectros C_l y P(k) (si existen)
# - Genera figuras simples en output/figures

import os
import numpy as np
import matplotlib.pyplot as plt

base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
out_dir = os.path.join(base_dir, "output")
fig_dir = os.path.join(out_dir, "figures")
os.makedirs(fig_dir, exist_ok=True)

def try_plot_cl():
    # Ejemplo: asumir un archivo 'Cls.dat' con l, C_l^TT, C_l^EE, ...
    fname = os.path.join(out_dir, "Cls.dat")
    if not os.path.exists(fname):
        print(f"[post] No encuentro {fname}, salto plot de C_l.")
        return
    data = np.loadtxt(fname)
    ell = data[:,0]
    clTT = data[:,1]

    plt.figure()
    plt.loglog(ell, ell*(ell+1)*clTT/(2*np.pi))
    plt.xlabel(r"$\ell$")
    plt.ylabel(r"$\ell(\ell+1)C_\ell^{TT}/2\pi$")
    plt.title("CET $\\Omega$: espectro TT")
    plt.tight_layout()
    plt.savefig(os.path.join(fig_dir, "Cl_TT_cetomega.png"), dpi=200)
    plt.close()
    print("[post] Figura C_l TT generada.")

def try_plot_pk():
    # Ejemplo: asumir 'Pk.dat' con k, P(k)
    fname = os.path.join(out_dir, "Pk.dat")
    if not os.path.exists(fname):
        print(f"[post] No encuentro {fname}, salto P(k).")
        return
    data = np.loadtxt(fname)
    k = data[:,0]
    pk = data[:,1]

    plt.figure()
    plt.loglog(k, pk)
    plt.xlabel(r"$k\,[h/\mathrm{Mpc}]$")
    plt.ylabel(r"$P(k)$")
    plt.title("CET $\\Omega$: espectro de potencias")
    plt.tight_layout()
    plt.savefig(os.path.join(fig_dir, "Pk_cetomega.png"), dpi=200)
    plt.close()
    print("[post] Figura P(k) generada.")

if __name__ == "__main__":
    try_plot_cl()
    try_plot_pk()
    print("[post] Listo.")
