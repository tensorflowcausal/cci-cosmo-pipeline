#!/usr/bin/env bash
# Script para lanzar CLASS con un ini de CET Ω
# Uso:
#   bash run_class_cetomega.sh ini/cetomega_example.ini

set -e

if [ $# -lt 1 ]; then
  echo "Uso: $0 ruta_al_ini"
  exit 1
fi

INI_FILE="$1"

# Carpeta donde asumimos que está CLASS ya compilado
CLASS_DIR="$(dirname "$0")/../class_public"

if [ ! -x "$CLASS_DIR/class" ]; then
  echo "ERROR: no encuentro el ejecutable 'class' en $CLASS_DIR"
  echo "Clona y compila CLASS, y asegúrate de que el binario se llame 'class'."
  exit 1
fi

OUT_DIR="$(dirname "$0")/../output"
mkdir -p "$OUT_DIR"

"$CLASS_DIR/class" "$INI_FILE"
