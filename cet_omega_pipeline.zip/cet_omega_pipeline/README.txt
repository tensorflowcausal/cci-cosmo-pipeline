
CET Ω – Pipeline cosmológico con CLASS (esqueleto)

Este ZIP contiene:
- scripts/run_class_cetomega.sh   -> script bash para lanzar CLASS con un módulo CET Ω
- scripts/postprocess_cetomega.py -> script Python para leer la salida y generar figuras
- ini/cetomega_example.ini        -> ejemplo de archivo .ini para CLASS extendido
- ini/cetomega_background.dat     -> tabla de ρ_Ω(a) precomputada de ejemplo (mock)
- notebooks/                      -> carpeta vacía para que pongas tus cuadernos
- output/                         -> carpeta donde se guardan resultados

IMPORTANTE:
1. DESCARGAR / INSTALAR CLASS:
   - Clonar desde: https://github.com/lesgourg/class_public
   - Compilar siguiendo las instrucciones oficiales.
   - Copiar o enlazar esa carpeta como: class_public/ dentro de este árbol.

2. MÓDULO CET Ω:
   - Todavía no existe un módulo oficial; debes implementar las ecuaciones de H(a),
     ρ_Ω(a), etc. dentro de CLASS (por ejemplo, modificando background.c, perturbations.c).
   - En el .ini se asumen parámetros extra: alpha_log, beta_psi, r_cet, etc.
     Tendrás que leerlos en input.c y usarlos en el background.

3. CÓMO USAR:
   - Edita ini/cetomega_example.ini con tus parámetros.
   - Lanza:
       bash scripts/run_class_cetomega.sh ini/cetomega_example.ini
   - CLASS generará archivos en output/.
   - Luego:
       python scripts/postprocess_cetomega.py
     que generará figuras (por ejemplo, C_l, P(k), etc.).

4. NOTAS:
   - Este es sólo un esqueleto 100% realista para que puedas trabajar.
   - Necesitas tú mismo programar el módulo CET Ω en CLASS.
   - Los nombres de archivos y rutas están pensados para que no tengas que tocar mucho.

